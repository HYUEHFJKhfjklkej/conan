# Original file comments:
# Copyright 2015 gRPC authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

require 'grpc'

module EchoWithoutProtobuf
  # The 'echo without protobuf' service definition.
  class Service

    include GRPC::GenericService

    self.marshal_class_method = :try_convert
    self.unmarshal_class_method = :try_convert
    self.service_name = 'EchoWithoutProtobuf'

    # Request and response are plain strings
    rpc :Echo, String, String
  end

  Stub = Service.rpc_stub_class
end
