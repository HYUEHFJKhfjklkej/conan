/****************************************************************************
**
** https://www.qxorm.com/
** Copyright (C) 2013 Lionel Marty (contact@qxorm.com)
**
** This file is part of the QxOrm library
**
** This software is provided 'as-is', without any express or implied
** warranty. In no event will the authors be held liable for any
** damages arising from the use of this software
**
** Commercial Usage
** Licensees holding valid commercial QxOrm licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and Lionel Marty
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 3.0 as published by the Free Software
** Foundation and appearing in the file 'license.gpl3.txt' included in the
** packaging of this file. Please review the following information to
** ensure the GNU General Public License version 3.0 requirements will be
** met : http://www.gnu.org/copyleft/gpl.html
**
** If you are unsure which license is appropriate for your use, or
** if you have questions regarding the use of this file, please contact :
** contact@qxorm.com
**
****************************************************************************/

#ifdef _QX_ENABLE_BOOST_SERIALIZATION
#ifndef _QX_SERIALIZE_QFLAGS_H_
#define _QX_SERIALIZE_QFLAGS_H_

#ifdef _MSC_VER
#pragma once
#endif

#include <boost/serialization/serialization.hpp>
#include <boost/serialization/split_free.hpp>
#include <boost/serialization/nvp.hpp>

#include <QtCore/qglobal.h>

namespace boost {
namespace serialization {

#if (QT_VERSION < QT_VERSION_CHECK(6, 2, 0))

template <class Archive, typename T>
inline void save(Archive & ar, const QFlags<T> & t, const unsigned int file_version)
{
   Q_UNUSED(file_version);
   int iValue = static_cast<int>(t);
   ar << boost::serialization::make_nvp("value", iValue);
}

template <class Archive, typename T>
inline void load(Archive & ar, QFlags<T> & t, const unsigned int file_version)
{
   Q_UNUSED(file_version);
   int iValue = 0;
   ar >> boost::serialization::make_nvp("value", iValue);
   t = QFlags<T>(QFlag(iValue));
}

template <class Archive, typename T>
inline void serialize(Archive & ar, QFlags<T> & t, const unsigned int file_version)
{
   boost::serialization::split_free(ar, t, file_version);
}

#else // (QT_VERSION < QT_VERSION_CHECK(6, 2, 0))

template <class Archive, typename T, typename std::enable_if<std::is_enum<T>::value, int>::type = 0>
inline void serialize(Archive & ar, QFlags<T> & t, const unsigned int file_version)
{
   Q_UNUSED(file_version);
   if (Archive::is_saving::value)
   {
      int iValue = static_cast<int>(t.toInt());
      ar & boost::serialization::make_nvp("value", iValue);
   }
   else
   {
      int iValue = 0;
      ar & boost::serialization::make_nvp("value", iValue);
      T eValue = static_cast<T>(iValue);
      t = QFlags<T>(eValue);
   }
}

#endif // (QT_VERSION < QT_VERSION_CHECK(6, 2, 0))

} // namespace boost
} // namespace serialization

#endif // _QX_SERIALIZE_QFLAGS_H_
#endif // _QX_ENABLE_BOOST_SERIALIZATION
